function Delta = RC2Delta(R,C)

Tau = R*C;
Delta = Tau*log(2);