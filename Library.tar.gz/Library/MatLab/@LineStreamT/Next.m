function Line = Next(Obj)

Ogj.LineNum = Obj.LineNum + 1;
Line = fgetl()