function Other = F2RorC(F, RorC)

Rad = 2*pi*F;
Tau = 1/Rad;
Other = Tau/RorC;