function F = RC2F(R, C)

Tau = R*C;
Rad = 1/Tau;
F = Rad/2/pi;