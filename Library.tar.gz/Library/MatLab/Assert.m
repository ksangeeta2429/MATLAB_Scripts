function Assert(Cond)

if (Cond == false)
  ERROR('Assertion Failur')
end