function Mil = MmToMil(Mm)

Mil = Mm/25.4 * 1e3;