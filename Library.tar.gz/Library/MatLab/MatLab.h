#ifndef EXPORT
#define EXPORT
#endif

EXPORT short int* readVals(short int *x);
EXPORT void writeVals(int Ival, int Qval);
EXPORT void close();
EXPORT int init(int startport);

