function Warn(Obj, Message)

WARNING(sprintf('%s; Line number %d', Message, Obj.LineNum));