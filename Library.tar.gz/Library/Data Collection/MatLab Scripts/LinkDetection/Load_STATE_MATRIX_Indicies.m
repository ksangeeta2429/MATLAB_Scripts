%% This script is used to load the indicies used in the state matrix 
%
%
% Author            : Bora Karaoglu, bora.karaoglu@samraksh.com, 2014
I_time = 1; I_position = [2,3]; I_V=[4,5];  