function SamAssert(Bool)

if ~Bool
  ERROR('Assertion failur')
end