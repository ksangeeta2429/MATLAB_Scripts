function Result = IsEven(N)

Result = (mod(round(N), 2) == 0);