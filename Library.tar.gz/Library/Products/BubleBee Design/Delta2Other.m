function Other = Delta2Other(Delta, ROrC)

Tau = Delta/log(2);
Other = Tau/ROrC;