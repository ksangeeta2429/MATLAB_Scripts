function G = TransOld(S)

G = TransLpOld(S) .* Trans63(S);