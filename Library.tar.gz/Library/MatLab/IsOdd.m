function Result = IsOdd(N)

Result = (mod(round(N), 2) == 1);